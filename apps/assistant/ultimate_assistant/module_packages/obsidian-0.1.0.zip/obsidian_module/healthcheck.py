"""Ready once at least one connected vault has the current plugin and the assistant agent."""
import json

from module_runtime import healthcheck as storage_check, records

from obsidian_module.server import vault_state

if __name__ == "__main__":
    import contextlib
    import io
    with contextlib.redirect_stdout(io.StringIO()):
        storage_check()  # raises on a broken local store
    vaults = [vault_state(r["vault"]) for r in records()]
    ready = any(v["ready"] for v in vaults)
    print(json.dumps({"status": "ready" if ready else "needs_setup",
                      "checks": ["local storage", "connected vault with assistant pane"],
                      "vaults": vaults}))
