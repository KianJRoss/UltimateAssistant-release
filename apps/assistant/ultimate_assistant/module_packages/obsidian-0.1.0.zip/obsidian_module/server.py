"""Obsidian module: the assistant as a chat pane inside the user's vault.

Connecting a vault installs the stock Agent Client plugin (pinned release,
checksum-verified) into it and adds one agent, "UltimateAssistant", that
launches the assistant's ACP interface (ultimate_assistant.acp_agent) with
this module's Obsidian guidance. That reaches the assistant's main node
through Herald, so Obsidian is just another interface to the one assistant:
same memory, conversations and tools.
"""
import hashlib
import json
import os
import shutil
import time
import urllib.request
from pathlib import Path

from module_runtime import TEXT, records, save, serve, tool

from obsidian_module.guidance import OBSIDIAN

PLUGIN_ID = "agent-client"
PLUGIN_VERSION = "0.13.0"
PLUGIN_URL = "https://github.com/RAIT-09/obsidian-agent-client/releases/download/" + PLUGIN_VERSION + "/{name}"
PLUGIN_FILES = {
    "main.js": "c82e4904c8749304158296222a050076b3b04a5fb86ec2ad7a7ff61477a1c0b4",
    "manifest.json": "3fc1d8d412bc9fc1ca4533d11a2ad2f2fac531fdd02c2626dbc0a0c82fdf6897",
    "styles.css": "254cfdda3f5076473f2993e04934da327f4f47425228c63ff31dcce95386b327",
}
AGENT_ID = "ultimate-assistant"


def data_dir():
    root = Path(os.environ["ULTIMATE_ASSISTANT_MODULE_DATA"])
    root.mkdir(parents=True, exist_ok=True)
    return root


def plugin_cache():
    """The pinned plugin release, downloaded once and verified."""
    cache = data_dir() / f"plugin-{PLUGIN_VERSION}"
    cache.mkdir(exist_ok=True)
    for name, digest in PLUGIN_FILES.items():
        path = cache / name
        if path.is_file() and hashlib.sha256(path.read_bytes()).hexdigest() == digest:
            continue
        with urllib.request.urlopen(PLUGIN_URL.format(name=name), timeout=60) as response:
            payload = response.read()
        if hashlib.sha256(payload).hexdigest() != digest:
            raise ValueError(f"Downloaded {name} failed its checksum; nothing was installed")
        path.write_bytes(payload)
    return cache


def find_assistant(explicit):
    """The Python that runs the assistant, and its app folder."""
    python = Path(explicit or os.environ.get("ULTIMATE_ASSISTANT_PYTHON") or "")
    app = os.environ.get("ULTIMATE_ASSISTANT_APP", "")
    if not python.is_file():
        raise ValueError("Could not find the assistant's Python on this device; pass assistant_python")
    return python, app


def write_launcher(python, app, router_url):
    """A small script the plugin runs; keeps paths and the router key out of the
    vault (the ACP interface reads HERALD_API_KEY from this device's setup)."""
    root = data_dir()
    guidance = root / "obsidian-interface.md"
    guidance.write_text(OBSIDIAN, encoding="utf-8")
    args = ["-m", "ultimate_assistant.acp_agent", "--interface-file", str(guidance)]
    if os.name == "nt":
        launcher = root / "ultimate-assistant-acp.cmd"
        launcher.write_text("@echo off\r\n"
                            + (f'set "PYTHONPATH={app}"\r\n' if app else "")
                            + f'set "HERALD_URL={router_url}"\r\n'
                            + " ".join(f'"{part}"' for part in [str(python), *args]) + " %*\r\n", encoding="utf-8")
    else:
        launcher = root / "ultimate-assistant-acp.sh"
        launcher.write_text("#!/bin/sh\n"
                            + (f"export PYTHONPATH='{app}'\n" if app else "")
                            + f"export HERALD_URL='{router_url}'\n"
                            + "exec " + " ".join(f"'{part}'" for part in [str(python), *args]) + ' "$@"\n', encoding="utf-8")
        launcher.chmod(0o755)
    return launcher


def install_plugin(vault, launcher):
    obsidian = vault / ".obsidian"
    target = obsidian / "plugins" / PLUGIN_ID
    backup = None
    if target.is_dir():
        manifest = target / "manifest.json"
        version = json.loads(manifest.read_text(encoding="utf-8")).get("version") if manifest.is_file() else None
        if version != PLUGIN_VERSION:
            # Outside plugins/: Obsidian would load a copy there as a second plugin with the same id.
            backup = obsidian / "plugin-backups" / f"{PLUGIN_ID}-{version or 'unknown'}-{time.strftime('%Y%m%d-%H%M%S')}"
            backup.parent.mkdir(exist_ok=True)
            shutil.copytree(target, backup)
    target.mkdir(parents=True, exist_ok=True)
    cache = plugin_cache()
    for name in PLUGIN_FILES:
        shutil.copyfile(cache / name, target / name)

    settings_path = target / "data.json"
    settings = json.loads(settings_path.read_text(encoding="utf-8")) if settings_path.is_file() else {}
    agents = [a for a in settings.get("customAgents") or [] if a.get("id") != AGENT_ID]
    command = str(launcher) if os.name == "nt" else "/bin/sh"
    args = [] if os.name == "nt" else [str(launcher)]
    agents.insert(0, {"id": AGENT_ID, "displayName": "UltimateAssistant", "command": command,
                      "args": args, "env": [], "enabled": True})
    settings["customAgents"] = agents
    settings["defaultAgentId"] = AGENT_ID
    settings_path.write_text(json.dumps(settings, indent=2), encoding="utf-8")

    enabled_path = obsidian / "community-plugins.json"
    enabled = json.loads(enabled_path.read_text(encoding="utf-8")) if enabled_path.is_file() else []
    if PLUGIN_ID not in enabled:
        enabled.append(PLUGIN_ID)
        enabled_path.write_text(json.dumps(enabled, indent=2), encoding="utf-8")
    return backup


def vault_state(vault):
    target = Path(vault) / ".obsidian" / "plugins" / PLUGIN_ID
    try:
        settings = json.loads((target / "data.json").read_text(encoding="utf-8"))
        manifest = json.loads((target / "manifest.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {"vault": str(vault), "ready": False, "problem": "plugin files or settings missing"}
    agent = next((a for a in settings.get("customAgents") or [] if a.get("id") == AGENT_ID), None)
    launcher_ok = bool(agent) and Path(agent["command"] if os.name == "nt" else agent["args"][0]).is_file()
    ready = manifest.get("version") == PLUGIN_VERSION and launcher_ok
    return {"vault": str(vault), "ready": ready, "plugin_version": manifest.get("version"),
            "default_agent": settings.get("defaultAgentId") == AGENT_ID,
            **({} if ready else {"problem": "plugin outdated or UltimateAssistant agent missing; connect the vault again"})}


TOOLS = [
    tool("connect_obsidian_vault",
         "Put the assistant inside an Obsidian vault the user names: installs the Agent Client chat plugin "
         f"({PLUGIN_VERSION}, verified) into that vault and sets it to talk to this assistant. Backs up a different "
         "existing copy of the plugin first. The user must reload Obsidian (or re-enable the plugin) afterwards.",
         {"vault_path": TEXT, "router_url": TEXT, "assistant_python": TEXT},
         ["vault_path"]),
    tool("obsidian_status", "List connected vaults and whether each one's assistant pane is set up correctly."),
]


def dispatch(name, args):
    if name == "obsidian_status":
        return {"vaults": [vault_state(r["vault"]) for r in records()]}
    vault = Path(args["vault_path"]).expanduser().resolve()
    if not (vault / ".obsidian").is_dir():
        raise ValueError(f"{vault} is not an Obsidian vault (no .obsidian folder); ask the user for the vault folder")
    router_url = args.get("router_url") or os.environ.get("HERALD_URL") or "http://127.0.0.1:8790"
    python, app = find_assistant(args.get("assistant_python"))
    launcher = write_launcher(python, app, router_url)
    backup = install_plugin(vault, launcher)
    existing = next((r for r in records() if r.get("vault") == str(vault)), None)
    save({"vault": str(vault), "router_url": router_url}, existing["id"] if existing else "")
    return {**vault_state(vault), "previous_plugin_backup": str(backup) if backup else None,
            "next_step": "Ask the user to reload Obsidian, then open the Agent Client chat; UltimateAssistant is the default agent."}


if __name__ == "__main__":
    serve("obsidian", TOOLS, dispatch)
