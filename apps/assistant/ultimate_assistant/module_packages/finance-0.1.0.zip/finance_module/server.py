from datetime import date
from decimal import Decimal, InvalidOperation

from module_runtime import TEXT, delete, records, save, serve, tool


def money(text, positive=False):
    try:
        amount = Decimal(text)
    except InvalidOperation as exc:
        raise ValueError("Amount must be decimal text") from exc
    if not amount.is_finite() or abs(amount) > Decimal("1000000000") or (positive and amount <= 0):
        raise ValueError("Invalid amount")
    return amount


TOOLS = [
    tool("save_cashflow_entry", "Save or replace a user-requested income or expense, expected or recorded. No bank connection or payments; use one consistent currency.",
         {"title": TEXT, "date": TEXT, "amount": TEXT, "currency": TEXT, "kind": TEXT, "status": TEXT, "category": TEXT, "record_id": TEXT},
         ["title", "date", "amount", "currency", "kind"]),
    tool("cashflow_forecast", "Forecast from a user-supplied opening balance at the start date, applying recorded and expected entries through the end date. Partial data produces only a partial forecast.",
         {"start_date": TEXT, "end_date": TEXT, "opening_balance": TEXT, "currency": TEXT}, ["start_date", "end_date", "opening_balance", "currency"]),
    tool("remove_cashflow_entry", "Remove a local ledger entry when requested.", {"record_id": TEXT}, ["record_id"]),
]


def dispatch(name, args):
    if name == "remove_cashflow_entry":
        return delete(args["record_id"])
    entries = records()
    currency = args["currency"].upper()
    if len(currency) != 3 or not currency.isalpha():
        raise ValueError("Provide a three-letter currency code")
    if name == "save_cashflow_entry":
        day = date.fromisoformat(args["date"])
        kind, status = args["kind"], args.get("status", "expected")
        if kind not in {"income", "expense"} or status not in {"expected", "recorded"}:
            raise ValueError("Use income/expense and expected/recorded")
        if not args["title"].strip() or len(args["title"]) > 300:
            raise ValueError("Title must be 1–300 characters")
        record_id = args.get("record_id", "")
        if record_id and not any(e["id"] == record_id for e in entries):
            raise ValueError("No entry has that ID")
        entry = save({"title": args["title"].strip(), "date": day.isoformat(), "amount": str(money(args["amount"], True)),
                      "currency": currency, "kind": kind, "status": status, "category": args.get("category", "other")[:100]}, record_id)
        return {"entry": entry}
    start, end = date.fromisoformat(args["start_date"]), date.fromisoformat(args["end_date"])
    if start > end:
        raise ValueError("End date must not precede start")
    balance = money(args["opening_balance"])
    opening_negative = balance < 0
    selected = sorted([e for e in entries if e["currency"] == currency and start <= date.fromisoformat(e["date"]) <= end], key=lambda e: e["date"])
    income, expenses = Decimal(0), Decimal(0)
    days = {}
    for entry in selected:
        amount = money(entry["amount"], True)
        if entry["kind"] == "income":
            income += amount
        else:
            expenses += amount
        days[entry["date"]] = days.get(entry["date"], Decimal(0)) + (amount if entry["kind"] == "income" else -amount)
    trajectory = []
    for day, change in sorted(days.items()):
        balance += change
        trajectory.append({"date": day, "closing_balance": str(balance)})
    return {"currency": currency, "income": str(income), "expenses": str(expenses), "closing_balance": str(balance),
            "daily_balances": trajectory, "negative_balance_dates": [d["date"] for d in trajectory if Decimal(d["closing_balance"]) < 0],
            "opening_balance_negative": opening_negative,
            "entries": selected, "basis": "Only supplied entries; daily totals do not establish intraday payment order"}


if __name__ == "__main__":
    serve("finance", TOOLS, dispatch)
