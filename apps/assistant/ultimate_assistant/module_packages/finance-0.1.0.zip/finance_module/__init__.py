"""Optional local cash-flow ledger."""
