from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP

from module_runtime import INTEGER, TEXT, delete, records, save, serve, tool


def moment(text):
    value = datetime.fromisoformat(text)
    if value.tzinfo is None:
        raise ValueError("Shift times require explicit UTC offsets")
    return value.astimezone(timezone.utc)


def rate(text):
    try:
        value = Decimal(text)
    except InvalidOperation as exc:
        raise ValueError("Hourly rate must be a decimal amount") from exc
    if not value.is_finite() or not 0 <= value <= 100000:
        raise ValueError("Invalid hourly rate")
    return value


TOOLS = [
    tool("save_work_shift", "Save or replace a requested planned/worked shift. Earnings are straight-time gross estimates, excluding taxes, tips, overtime, and employer rounding.",
         {"employer": TEXT, "start": TEXT, "end": TEXT, "unpaid_break_minutes": INTEGER, "hourly_rate": TEXT,
          "currency": TEXT, "status": TEXT, "record_id": TEXT}, ["employer", "start", "end", "hourly_rate", "currency"]),
    tool("work_summary", "List shifts overlapping a range and estimate gross earnings for full shifts starting in that range. Planned and worked totals are separate.",
         {"start": TEXT, "end": TEXT}, ["start", "end"]),
    tool("remove_work_shift", "Remove a saved shift when requested.", {"record_id": TEXT}, ["record_id"]),
]


def dispatch(name, args):
    if name == "remove_work_shift":
        return delete(args["record_id"])
    start, end = moment(args["start"]), moment(args["end"])
    if start >= end:
        raise ValueError("End must follow start")
    shifts = records()
    if name == "save_work_shift":
        if not args["employer"].strip() or len(args["employer"]) > 300:
            raise ValueError("Employer must be 1–300 characters")
        minutes = Decimal(str((end - start).total_seconds())) / 60
        unpaid = args.get("unpaid_break_minutes", 0)
        if not 0 <= unpaid < minutes or minutes > 1440:
            raise ValueError("Shift must be at most 24 hours and unpaid breaks shorter than the shift")
        status = args.get("status", "planned")
        currency = args["currency"].upper()
        if status not in {"planned", "worked"} or len(currency) != 3 or not currency.isalpha():
            raise ValueError("Use planned/worked status and a three-letter currency code")
        record_id = args.get("record_id", "")
        if record_id and not any(s["id"] == record_id for s in shifts):
            raise ValueError("No shift has that ID")
        earnings = ((minutes - unpaid) / 60 * rate(args["hourly_rate"])).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        overlaps = [s for s in shifts if s["id"] != record_id and moment(s["start"]) < end and moment(s["end"]) > start]
        shift = save({"employer": args["employer"].strip(), "start": args["start"], "end": args["end"],
                      "unpaid_break_minutes": unpaid, "paid_minutes": str(minutes - unpaid), "hourly_rate": str(rate(args["hourly_rate"])),
                      "estimated_gross": str(earnings), "currency": currency, "status": status}, record_id)
        return {"shift": shift, "overlaps": overlaps, "estimate_only": True}
    visible = [s for s in shifts if moment(s["start"]) < end and moment(s["end"]) > start]
    totals = {}
    for s in visible:
        if start <= moment(s["start"]) < end:
            key = s["currency"] + ":" + s["status"]
            totals[key] = totals.get(key, Decimal(0)) + Decimal(s["estimated_gross"])
    return {"shifts": visible, "estimated_gross_by_currency_and_status": {k: str(v) for k, v in totals.items()},
            "basis": "Full shifts starting in the requested range; straight-time gross only"}


if __name__ == "__main__":
    serve("work", TOOLS, dispatch)
