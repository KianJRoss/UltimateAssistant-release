"""Optional shift and hours tracking."""
