"""Manager-supplied employee records; no employer connection or schedule publication."""
from datetime import datetime, timezone

from module_runtime import INTEGER, TEXT, delete, records, save, serve, tool

TEXTS = {"type": "array", "items": TEXT}
TOOLS = [
    tool("manager_setup_questions", "Find the next simple question for guided manager setup. Ask one question at a time; save answers through the corresponding tools. Employee observations are manager-supplied, not verified facts.", {}, []),
    tool("save_team_settings", "Save workplace scheduling context supplied by the manager; policy notes are not legal validation.",
         {"workplace": TEXT, "timezone": TEXT, "coverage_notes": TEXT, "policy_notes": TEXT}, ["workplace", "timezone"]),
    tool("save_employee", "Save an employee's manager-supplied role, trained skills, preferred hours and notes. Use concrete work observations rather than inferred personal traits. Missing information stays unknown.",
         {"name": TEXT, "roles": TEXTS, "skills": TEXTS, "notes": TEXT, "maximum_weekly_minutes": INTEGER, "record_id": TEXT}, ["name", "roles", "skills"]),
    tool("save_employee_availability", "Save a confirmed availability window for an employee using exact dates and timezone offsets. Expand recurring availability into requested dates after confirming the pattern. No window means unknown, not unavailable.",
         {"employee_id": TEXT, "start": TEXT, "end": TEXT, "notes": TEXT, "record_id": TEXT}, ["employee_id", "start", "end"]),
    tool("save_employee_observation", "Record a dated, manager-supplied work observation, including strengths, reliability, training needs or recurring work habits. Preserve the source and uncertainty; do not label it independently verified.",
         {"employee_id": TEXT, "date": TEXT, "category": TEXT, "observation": TEXT}, ["employee_id", "date", "category", "observation"]),
    tool("save_pairing_rule", "Record a manager-requested avoid/prefer pairing and the work-related reason. Avoid rules block an overlapping proposed assignment; prefer rules are advisory.",
         {"first_employee_id": TEXT, "second_employee_id": TEXT, "rule": TEXT, "reason": TEXT, "record_id": TEXT}, ["first_employee_id", "second_employee_id", "rule", "reason"]),
    tool("list_management_records", "Read manager records, optionally for one employee. Keep them private to this installation; do not include employee information in diagnostic reports.", {"employee_id": TEXT}, []),
    tool("check_manager_schedule", "Check a proposed schedule for known roles, availability, overlapping shifts, avoid pairings and supplied weekly minute caps. Returns unknowns explicitly. Does not check employment law, store coverage, break rules or employer policy automatically, and does not publish a schedule.",
         {"shifts_json": TEXT}, ["shifts_json"]),
    tool("remove_management_record", "Remove a record when requested. Removing an employee also removes their related availability, observations and pairing rules.", {"record_id": TEXT}, ["record_id"]),
]


def moment(value):
    result = datetime.fromisoformat(value)
    if result.tzinfo is None:
        raise ValueError("Dates need explicit timezone offsets")
    return result.astimezone(timezone.utc)


def bounded(value, label, maximum=4000):
    if not isinstance(value, str) or not value.strip() or len(value) > maximum:
        raise ValueError(f"{label} must be nonempty text of at most {maximum} characters")
    return value.strip()


def employee(items, identifier):
    found = next((item for item in items if item["id"] == identifier and item["kind"] == "employee"), None)
    if not found:
        raise ValueError("Unknown employee ID")
    return found


def dispatch(name, args):
    items = records()
    if name == "manager_setup_questions":
        team = next((item for item in items if item["kind"] == "team"), None)
        people = [item for item in items if item["kind"] == "employee"]
        if not team:
            question = "What manager task would you like help with first, and which workplace is it for?"
        elif not team.get("coverage_notes"):
            question = "What hours and roles need coverage, and how many people do you need in each role?"
        elif not people:
            question = "Who is on your team, and what roles can each person work?"
        else:
            missing = next((person for person in people if not any(item["kind"] == "availability" and item.get("employee_id") == person["id"] for item in items)), None)
            question = f"When is {missing['name']} available for the dates you want to schedule?" if missing else "Are there any people who should not work together, training needs, or work habits I should account for?"
        return {"question": question, "employees_recorded": len(people), "next_step": "Ask the manager; do not invent missing answers"}
    if name == "list_management_records":
        identifier = args.get("employee_id")
        if identifier:
            employee(items, identifier)
            items = [item for item in items if item["id"] == identifier or item.get("employee_id") == identifier or identifier in (item.get("first_employee_id"), item.get("second_employee_id"))]
        return {"records": items, "source": "Manager-supplied information; not independently verified"}
    if name == "remove_management_record":
        identifier = args["record_id"]
        target = next((item for item in items if item["id"] == identifier), None)
        if not target:
            raise ValueError("Unknown record ID")
        related = [item["id"] for item in items if target["kind"] == "employee" and (item.get("employee_id") == identifier or identifier in (item.get("first_employee_id"), item.get("second_employee_id")))]
        for linked in related:
            delete(linked)
        delete(identifier)
        return {"removed": identifier, "related_records_removed": len(related)}
    if name == "check_manager_schedule":
        return check_schedule(items, args["shifts_json"])
    record_id = args.get("record_id", "")
    kinds = {"save_employee": "employee", "save_employee_availability": "availability", "save_pairing_rule": "pairing"}
    if record_id and not any(item["id"] == record_id and item["kind"] == kinds.get(name) for item in items):
        raise ValueError("Record ID does not match this record type")
    if name == "save_team_settings":
        previous = next((item for item in items if item["kind"] == "team"), None)
        record_id = previous["id"] if previous else ""
        value = {"kind": "team", "workplace": bounded(args["workplace"], "Workplace", 300), "timezone": bounded(args["timezone"], "Timezone", 100),
                 "coverage_notes": args.get("coverage_notes", "")[:4000], "policy_notes": args.get("policy_notes", "")[:4000]}
    elif name == "save_employee":
        roles, skills = args["roles"], args["skills"]
        if not isinstance(roles, list) or not isinstance(skills, list) or len(roles) > 30 or len(skills) > 50:
            raise ValueError("Provide bounded role and skill lists")
        cap = args.get("maximum_weekly_minutes")
        if cap is not None and not 0 <= cap <= 10080:
            raise ValueError("Invalid weekly minute cap")
        value = {"kind": "employee", "name": bounded(args["name"], "Employee name", 200), "roles": [bounded(role, "Role", 100) for role in roles],
                 "skills": [bounded(skill, "Skill", 100) for skill in skills], "notes": args.get("notes", "")[:4000], "maximum_weekly_minutes": cap}
    elif name == "save_employee_availability":
        employee(items, args["employee_id"])
        if moment(args["start"]) >= moment(args["end"]):
            raise ValueError("Availability end must follow start")
        value = {"kind": "availability", "employee_id": args["employee_id"], "start": args["start"], "end": args["end"], "notes": args.get("notes", "")[:4000]}
    elif name == "save_employee_observation":
        employee(items, args["employee_id"])
        datetime.fromisoformat(args["date"])
        value = {"kind": "observation", "employee_id": args["employee_id"], "date": args["date"], "category": bounded(args["category"], "Category", 100),
                 "observation": bounded(args["observation"], "Observation"), "source": "manager", "independently_verified": False}
    elif name == "save_pairing_rule":
        employee(items, args["first_employee_id"])
        employee(items, args["second_employee_id"])
        if args["first_employee_id"] == args["second_employee_id"] or args["rule"] not in {"avoid", "prefer"}:
            raise ValueError("Pairing requires two different employees and avoid/prefer rule")
        value = {"kind": "pairing", **{key: args[key] for key in ("first_employee_id", "second_employee_id", "rule")}, "reason": bounded(args["reason"], "Reason")}
    else:
        raise ValueError("Unknown management tool")
    return {"record": save(value, record_id), "source": "manager"}


def check_schedule(items, raw):
    import json
    shifts = json.loads(raw)
    if not isinstance(shifts, list) or len(shifts) > 500:
        raise ValueError("Provide at most 500 proposed shifts")
    conflicts, unknowns, normalized, totals = [], [], [], {}
    for index, shift in enumerate(shifts):
        person = employee(items, shift["employee_id"])
        start, end = moment(shift["start"]), moment(shift["end"])
        if start >= end or (end - start).total_seconds() > 86400:
            raise ValueError("Shifts must be positive and at most 24 hours")
        if shift["role"] not in person["roles"]:
            conflicts.append({"shift": index, "reason": "Role not recorded for employee"})
        windows = [item for item in items if item["kind"] == "availability" and item["employee_id"] == person["id"]]
        if not windows:
            unknowns.append({"shift": index, "reason": "Availability not recorded"})
        elif not any(moment(window["start"]) <= start and moment(window["end"]) >= end for window in windows):
            conflicts.append({"shift": index, "reason": "Outside recorded availability"})
        local_start, local_end = datetime.fromisoformat(shift["start"]), datetime.fromisoformat(shift["end"])
        week = local_start.isocalendar()[:2]
        if local_end.isocalendar()[:2] != week:
            unknowns.append({"shift": index, "reason": "Cross-week shift needs manual hours allocation"})
        key = (person["id"], week)
        totals[key] = totals.get(key, 0) + (end - start).total_seconds() / 60
        normalized.append((person["id"], start, end, index))
    for position, (first, start, end, index) in enumerate(normalized):
        for second, other_start, other_end, other_index in normalized[position + 1:]:
            if start >= other_end or end <= other_start:
                continue
            if first == second:
                conflicts.append({"shifts": [index, other_index], "reason": "Employee has overlapping shifts"})
            elif any(item["kind"] == "pairing" and item["rule"] == "avoid" and {item["first_employee_id"], item["second_employee_id"]} == {first, second} for item in items):
                conflicts.append({"shifts": [index, other_index], "reason": "Recorded avoid pairing"})
    for (identifier, week), minutes in totals.items():
        cap = employee(items, identifier).get("maximum_weekly_minutes")
        if cap is not None and minutes > cap:
            conflicts.append({"employee_id": identifier, "week": list(week), "reason": "Supplied weekly minute cap exceeded", "minutes": minutes, "cap": cap})
    return {"conflicts": conflicts, "unknowns": unknowns, "known_constraints_passed": not conflicts,
            "ready_for_manager_review": not conflicts and not unknowns, "published": False,
            "unchecked": ["coverage requirements", "break rules", "employment law", "unrecorded employer policies"]}


if __name__ == "__main__":
    serve("management", TOOLS, dispatch)
