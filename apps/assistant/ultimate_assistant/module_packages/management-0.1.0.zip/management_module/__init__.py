"""Optional local manager records and schedule checks."""
