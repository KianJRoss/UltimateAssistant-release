"""Small stdio MCP transport and local record store for first-party modules."""
import json
from contextlib import closing
import os
import sqlite3
import sys
import uuid
from pathlib import Path


def connect():
    root = Path(os.environ["ULTIMATE_ASSISTANT_MODULE_DATA"])
    root.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(root / "records.sqlite3", timeout=15)
    db.execute("CREATE TABLE IF NOT EXISTS records (id TEXT PRIMARY KEY, payload TEXT NOT NULL)")
    return db


def records():
    with closing(connect()) as db, db:
        return [dict(json.loads(row[1]), id=row[0]) for row in db.execute("SELECT id,payload FROM records ORDER BY rowid")]


def save(record, record_id=""):
    record_id = record_id or uuid.uuid4().hex
    with closing(connect()) as db, db:
        if record.get("id"):
            record = {k: v for k, v in record.items() if k != "id"}
        db.execute("INSERT INTO records VALUES (?,?) ON CONFLICT(id) DO UPDATE SET payload=excluded.payload",
                   (record_id, json.dumps(record)))
    return dict(record, id=record_id)


def delete(record_id):
    with closing(connect()) as db, db:
        count = db.execute("DELETE FROM records WHERE id=?", (record_id,)).rowcount
    if not count:
        raise ValueError("No record has that ID")
    return {"removed": record_id}


def tool(name, description, properties=None, required=None):
    return {"name": name, "description": description, "inputSchema": {
        "type": "object", "properties": properties or {}, "required": required or [], "additionalProperties": False}}


def serve(name, tools, dispatch):
    sys.stdin.reconfigure(encoding="utf-8")
    sys.stdout.reconfigure(encoding="utf-8")
    for line in sys.stdin:
        try:
            request = json.loads(line)
        except ValueError:
            print(json.dumps({"jsonrpc": "2.0", "id": None, "error": {"code": -32700, "message": "Invalid JSON"}}), flush=True)
            continue
        if not isinstance(request, dict):
            continue
        if "id" not in request:
            continue
        reply = {"jsonrpc": "2.0", "id": request["id"]}
        method = request.get("method")
        params = request.get("params", {})
        if method == "initialize":
            version = params.get("protocolVersion")
            reply["result"] = {"protocolVersion": version if version in {"2024-11-05", "2025-03-26"} else "2025-03-26",
                               "capabilities": {"tools": {}}, "serverInfo": {"name": name, "version": "0.1.0"}}
        elif method == "ping":
            reply["result"] = {}
        elif method == "tools/list":
            reply["result"] = {"tools": tools}
        elif method == "tools/call":
            try:
                schema = next(t["inputSchema"] for t in tools if t["name"] == params.get("name"))
                arguments = params.get("arguments", {})
                if not isinstance(arguments, dict) or set(arguments) - set(schema["properties"]) or set(schema["required"]) - set(arguments):
                    raise ValueError("Invalid tool arguments")
                for key, value in arguments.items():
                    expected = schema["properties"][key].get("type")
                    if expected == "string" and not isinstance(value, str):
                        raise ValueError(f"{key} must be text")
                    if expected == "integer" and (not isinstance(value, int) or isinstance(value, bool)):
                        raise ValueError(f"{key} must be an integer")
                result = dispatch(params["name"], arguments)
                reply["result"] = {"content": [{"type": "text", "text": json.dumps(result)}], "isError": False}
            except (ValueError, KeyError, StopIteration) as exc:
                reply["result"] = {"content": [{"type": "text", "text": str(exc) or "Unknown tool"}], "isError": True}
            except Exception:
                reply["result"] = {"content": [{"type": "text", "text": "Local module operation failed; no success was confirmed"}], "isError": True}
        else:
            reply["error"] = {"code": -32601, "message": "Unsupported method"}
        print(json.dumps(reply, ensure_ascii=False), flush=True)


def healthcheck():
    with closing(connect()) as db, db:
        result = db.execute("PRAGMA quick_check").fetchone()[0]
        if result != "ok":
            raise RuntimeError("Local database integrity check failed")
        db.execute("BEGIN IMMEDIATE")
        db.rollback()
    print(json.dumps({"status": "ready", "checks": ["local storage", "database integrity", "write transaction"]}))


TEXT = {"type": "string"}
INTEGER = {"type": "integer"}
