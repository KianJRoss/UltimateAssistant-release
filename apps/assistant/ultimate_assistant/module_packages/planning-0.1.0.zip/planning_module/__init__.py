"""Optional local planning tools."""
