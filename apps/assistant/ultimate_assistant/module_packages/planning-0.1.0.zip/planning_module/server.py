from datetime import datetime, timedelta, timezone

from module_runtime import INTEGER, TEXT, delete, records, save, serve, tool


def moment(value):
    result = datetime.fromisoformat(value)
    if result.tzinfo is None:
        raise ValueError("Provide a timestamp with a UTC offset; ask the user for their timezone if unknown")
    return result.astimezone(timezone.utc)


def interval(start, end):
    a, b = moment(start), moment(end)
    if a >= b:
        raise ValueError("End must follow start")
    return a, b


TOOLS = [
    tool("save_plan_block", "Save or replace a user-requested class, shift, study, travel, or personal time block. Explicit offset timestamps required; no calendar sync or notifications.",
         {"title": TEXT, "start": TEXT, "end": TEXT, "category": TEXT, "notes": TEXT, "record_id": TEXT}, ["title", "start", "end"]),
    tool("list_plan", "List saved blocks and overlapping commitments in a time window.", {"start": TEXT, "end": TEXT}, ["start", "end"]),
    tool("find_free_time", "Find free intervals within user-specified waking/available hours. Includes optional buffer around commitments; does not schedule automatically.",
         {"start": TEXT, "end": TEXT, "minimum_minutes": INTEGER, "buffer_minutes": INTEGER}, ["start", "end", "minimum_minutes"]),
    tool("remove_plan_block", "Remove a saved time block only when requested.", {"record_id": TEXT}, ["record_id"]),
]


def dispatch(name, args):
    if name == "remove_plan_block":
        return delete(args["record_id"])
    start, end = interval(args["start"], args["end"])
    blocks = records()
    if name == "save_plan_block":
        if not args["title"].strip() or len(args["title"]) > 300:
            raise ValueError("Title must be 1–300 characters")
        record_id = args.get("record_id", "")
        if record_id and not any(b["id"] == record_id for b in blocks):
            raise ValueError("No block has that ID")
        category = args.get("category", "personal")
        if category not in {"class", "work", "study", "travel", "personal", "break"}:
            raise ValueError("Unknown planning category")
        overlaps = [b for b in blocks if b["id"] != record_id and moment(b["start"]) < end and moment(b["end"]) > start]
        block = save({"title": args["title"].strip(), "start": args["start"], "end": args["end"],
                      "category": category, "notes": args.get("notes", "")[:4000]}, record_id)
        return {"block": block, "overlaps": overlaps, "notifications": False}
    blocks = sorted([b for b in blocks if moment(b["start"]) < end and moment(b["end"]) > start], key=lambda b: moment(b["start"]))
    if name == "list_plan":
        conflicts = [{"first": a["id"], "second": b["id"]} for i, a in enumerate(blocks) for b in blocks[i + 1:]
                     if moment(b["start"]) < moment(a["end"])]
        return {"blocks": blocks, "conflicts": conflicts}
    minimum = args["minimum_minutes"]
    buffer = args.get("buffer_minutes", 0)
    if not 1 <= minimum <= 1440 or not 0 <= buffer <= 240:
        raise ValueError("Minimum must be 1–1440 minutes; buffer 0–240")
    cursor, slots = start, []
    occupied = sorted([(max(start, moment(b["start"]) - timedelta(minutes=buffer)),
                        min(end, moment(b["end"]) + timedelta(minutes=buffer))) for b in records()
                       if moment(b["start"]) - timedelta(minutes=buffer) < end and moment(b["end"]) + timedelta(minutes=buffer) > start])
    for a, b in occupied + [(end, end)]:
        if (a - cursor).total_seconds() >= minimum * 60:
            slots.append({"start": cursor.isoformat(), "end": a.isoformat(), "minutes": int((a - cursor).total_seconds() / 60)})
        cursor = max(cursor, b)
    return {"free_intervals": slots, "timezone": "UTC", "saved": False}


if __name__ == "__main__":
    serve("planning", TOOLS, dispatch)
