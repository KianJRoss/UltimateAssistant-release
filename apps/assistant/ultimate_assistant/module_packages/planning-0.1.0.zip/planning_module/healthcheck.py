from module_runtime import healthcheck

if __name__ == "__main__":
    healthcheck()
